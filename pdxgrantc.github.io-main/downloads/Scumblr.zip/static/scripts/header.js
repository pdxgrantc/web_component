console.log('header script loaded');
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('status').innerText === 'true') {
        console.log('<HEADER> logged in');
        document.getElementById('user-dropdown').style.display = 'block';
        document.getElementsByClassName('username-button')[0].addEventListener('click', () => {
            window.location.href = 'http://localhost:5555/' + document.getElementsByClassName('username-button')[0].innerText;
        });

        document.getElementById('logout-button').addEventListener('click', () => {
            var xhr = new XMLHttpRequest();
            xhr.open('POST', '/logout');
            xhr.send();
        });
    } else {
        console.log('<HEADER> not logged in');
        document.getElementById('login-buttons').style.display = 'block';
    }

    document.getElementById('header-searchbar').addEventListener('keypress', function (e) {
        if (e.key === 'Enter') {
            window.location.href = "http://" + document.location.host + '/search/' + document.getElementById('searchbar').value;
        }
    });
});