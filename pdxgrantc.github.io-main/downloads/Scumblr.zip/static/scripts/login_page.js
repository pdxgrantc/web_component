console.log("login_page.js");

String.prototype.hashCode = function () {
    var hash = 0, i, chr;
    if (this.length === 0) return hash;
    for (i = 0; i < this.length; i++) {
        chr = this.charCodeAt(i);
        hash = ((hash << 5) - hash) + chr;
        hash |= 0; // Convert to 32bit integer
    }
    return hash;
};

document.addEventListener("DOMContentLoaded", function () {
    var submit = document.getElementById('submit-button');
    console.log("adding event listener")

    submit.addEventListener('click', function () {
        const xhr = new XMLHttpRequest();

        var username = document.getElementById('username');
        var password = document.getElementById('password');

        var post_data = '{"username":"' + username.value + '", "password":"' + password.value.hashCode() + '"}'

        console.log("Sending: " + post_data);

        xhr.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                if (this.responseText == "Thanks for logging in!") {
                    window.location.href = "http://" + document.location.host + '/';
                } else {
                    alert(this.responseText)
                }
            }
        };

        xhr.open("POST", '/new_login')
        xhr.setRequestHeader('Content-Type', 'text/plain');
        xhr.send(post_data);
    })
});