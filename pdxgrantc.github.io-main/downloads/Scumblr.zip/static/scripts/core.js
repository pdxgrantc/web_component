/* INCLUDED ON EVERY PAGE ON SITE */

document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM loaded successfully');
});