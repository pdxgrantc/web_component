document.addEventListener('DOMContentLoaded', function () {
    var submit_button = document.getElementById("submit-button");

    submit_button.addEventListener("click", function () {
        var post_title = document.getElementById("title").value;
        var post_content = tinyMCE.activeEditor.getContent();

        sanitized_title = post_title.replaceAll('"', "'");
        sanitized_content = post_content.replaceAll('"', "'");
        sanitized_content = sanitized_content.replaceAll('\n', '<br>');

        var post_data = '{"title":"' + sanitized_title + '", "body":"' + sanitized_content + '", "user":"' + 'TODO' + '"}'

        const xhr = new XMLHttpRequest();

        xhr.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                console.log(this.readyState) // should be 4
                console.log(this.status) // should be 200 OK
                console.log(this.responseText) // response return from request

                window.location.href = "http://" + document.location.host + this.responseText;
            } else {
                console.log("request processing...")
            }
        };

        xhr.open("POST", '/create_post')
        xhr.setRequestHeader('Content-Type', 'text/plain');
        xhr.send(post_data);
    })
})