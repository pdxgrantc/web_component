console.log("login_page.js");

String.prototype.hashCode = function () {
    var hash = 0, i, chr;
    if (this.length === 0) return hash;
    for (i = 0; i < this.length; i++) {
        chr = this.charCodeAt(i);
        hash = ((hash << 5) - hash) + chr;
        hash |= 0; // Convert to 32bit integer
    }
    return hash;
};

document.addEventListener("DOMContentLoaded", function () {
    var confirm_password = document.getElementById("confirm-password");
    confirm_password.addEventListener("blur", function () {
        var password = document.getElementById("password");
        if (password.value !== confirm_password.value) {
            alert("Passwords do not match");
        }
    });

    var submit = document.getElementById('submit-button');
    console.log("adding event listener")

    submit.addEventListener('click', function () {
        var confirm_password = document.getElementById("confirm-password");
        var password = document.getElementById('password');

        if (confirm_password.value === password.value) {
            const xhr = new XMLHttpRequest();

            var username = document.getElementById('username');

            var post_data = '{"username":"' + username.value + '", "password":"' + password.value.hashCode() + '"}'

            console.log("Sending: " + post_data);

            xhr.onreadystatechange = function (username) {
                if (this.readyState == 4 && this.status == 200) {
                    console.log(this.readyState) // should be 4
                    console.log(this.status) // should be 200 OK
                    console.log(this.responseText) // response return from request
                    window.location.href = "http://" + document.location.host + "/login";
                } else {
                    console.log("request processing...")
                }
            };

            xhr.open("POST", '/new_signup')
            xhr.setRequestHeader('Content-Type', 'text/plain');
            xhr.send(post_data);
        } else {
            alert("Passwords do not match.");
        }
    })
});