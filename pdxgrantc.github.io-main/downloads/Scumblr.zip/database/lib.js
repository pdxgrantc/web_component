// library file to query the db.json file for Scumblr

/* USER DATA STRUCTURE: */
/* 
{
    "username": "Dublin",
    "password": "1557372922",
    "posts": [
      {
        "title": "The Spire",
        "keyTime": 1639088967036,
        "year": 2021,
        "month": 11,
        "day": 9,
        "hour": 14,
        "min": 29,
        "text": "<p>The&nbsp;<strong>Spire of Dublin</strong>,&nbsp;alternatively titled&nbsp;<strong>The Monument of Light</strong>, is a large, stainless steel, pin-like monument 120 metres (390 ft) in height, located on the site of the former Nelson's Piller and statue of William Blakeney on O'connel Street in Dublin, Ireland.</p><br><p style='text-align: center;'><img src='https://upload.wikimedia.org/wikipedia/commons/thumb/1/1b/E4324-Spire-of-Dublin.jpg/240px-E4324-Spire-of-Dublin.jpg' alt='E4324-Spire-of-Dublin.jpg' /></p>",
        "username": "Dublin"
      },
      {
        "title": "Temple Bar",
        "keyTime": 1639089403852,
        "year": 2021,
        "month": 11,
        "day": 9,
        "hour": 14,
        "min": 36,
        "text": "<p>Temple Bar is an area on the south bank of the River Liffey in Central Dublin, Ireland. The area is bounded by the Liffey to the north, Dame Street to the south, Westmoreland Street to the east and Fishamble Street to the west. It is promoted as Dublin's 'cultural quarter' and as a centre of Dublin's city centre's nightlife, is a tourist destination.</p><br><p style='text-align: center;'><img src='https://upload.wikimedia.org/wikipedia/commons/thumb/f/f7/TempleBar.JPG/250px-TempleBar.JPG' alt='Temple Bar Square' /></p>",
        "username": "Dublin"
      }
    ]
  }
*/


const { count } = require('console');
const fs = require('fs');
const { exit, title } = require('process');

class Database {
    constructor() {
        this.users = [];
        this.readIn();
    }

    makeUser(newUsername, newPassword) {
        let d = new Date();
        var newUser = {
            username: newUsername,
            password: newPassword,
            keyTime: d.getTime(),
            year: d.getFullYear(),
            month: d.getMonth(),
            monthString: d.toLocaleString('default', { month: 'long' }),
            day: d.getDate(),
            hour: d.getHours(),
            min: d.getMinutes(),
            posts: []
        };

        return newUser;
    }

    makePost(newTitle, newText, newUsername) {
        var d = new Date()
        var newPost = {
            title: newTitle,
            keyTime: d.getTime(),
            year: d.getFullYear(),
            month: d.getMonth(),
            day: d.getDate(),
            hour: d.getHours(),
            min: d.getMinutes(),
            text: newText,
            username: newUsername
        };

        return newPost;
    }

    /*
     * Return Values
     * 0 successful and added to the database
     * 1 there is a post with this title already
    */
    newUser(username, password) {
        for (let i = 0; i < this.users.length; i++) {
            if (this.users[i].username == username) {
                return 1;
            }
        }
        var newUser = this.makeUser(username, password);
        this.users.push(newUser);
        this.writeToFile();
        return 0;
        }

    /*
     * Return Values
     * 0 successfull and added to the database
     * 1 there is a post with this title already
     * 2 the username given does not exist
    */
    newPost(username, newTitle, text) {
        let userIndex = -1;
        for (let i = 0; i < this.users.length; i++) {
            if (this.users[i].username === username) {
                for (let j = 0; j < this.users[i].posts.length; j++) {
                    if (this.users[i].posts[j].title === newTitle) 
                        return 1;
                }
                userIndex = i;
                break;
            }
        }
        if (userIndex === -1) 
            return 2;
        var newPost = this.makePost(newTitle, text, username);
        this.users[userIndex].posts.push(newPost);
        this.writeToFile();
        return 0;
    }
 
    writeToFile() {
        this.deleteContents();
        const jsonString = JSON.stringify(this.users, null, 2);
        fs.writeFileSync(__dirname + '/data/db.json', jsonString);
    }

    deleteContents() {
        fs.unlinkSync(__dirname + '/data/db.json');
    }

    readIn() {
        try {
            let json = require(__dirname + '/data/db.json');
            this.users = json;
        }
        catch {
            this.newUser("root", "password");
        }
    }

    getUser(username) {
        for (let i = 0; i < this.users.length; i++) {
            if (this.users[i].username == username) {
                return this.users[i];
            }
        }
    }
    getUsers() {
        return this.users;
    }
    getPost(title) {
        for (let i = 0; i < this.users.length; i++) {
            for (let j = 0; j < this.users[i].posts.length; j++) {
                if (this.users[i].posts[j].title == title) {
                    return this.users[i].posts[j];
                }
            }
        }
    }
    getPosts(username) {
        for (let i = 0; i < this.users.length; i++) {
            if (this.users[i].username == username) {
                return this.users[i].posts;
            }
        }
    }

    searchPostsByTitle(title) {
        var posts = [];
        var simplifiedTitle = "";
        for (let i = 0; i < this.users.length; i++) {
            for (let j = 0; j < this.users[i].posts.length; j++) {
                simplifiedTitle = this.users[i].posts[j].title.replace(/[^a-zA-Z ]/g, "").toLowerCase();
                if (simplifiedTitle.includes(title.toLowerCase())) {
                    posts.push(this.users[i].posts[j]);
                }
            }
        }
        return posts;
    }

    searchUsersByUsername(username) {
        var users = [];
        for (let i = 0; i < this.users.length; i++) {
            if (this.users[i].username.toLowerCase().includes(username.toLowerCase())) {
                users.push(this.users[i]);
            }
        }
        return users;
    }

    // test functions (FOR DEBUGGING)
    printUsers() {
        for (let i = 0; i < this.users.length; i++) {
            console.log(this.users[i].username + ", " + this.users[i].password);
        }
    }

    printPosts() {
        for (let i = 0; i < this.users.length; i++) {
            for (let j = 0; j < this.users[i].posts.length; j++) {
                console.log(this.users[i].posts[j].username + ", " + this.users[i].posts[j].title + ", " + this.users[i].posts[j].text);;
                console.log(this.users[i].posts[j].month + " " + this.users[i].posts[j].day + ", " + this.users[i].posts[j].year);;
            }
        }
    }

    printObj() {
        console.log(this.users);
    }

    // TODO return sorted highest
    latestPosts(numberWanted) {
        var num = numberWanted, counter = 0, cacheAryPosts = [], returnAryPosts = [];
        for (let i = 0; i < this.users.length; i++) {
            for (let j = 0; j < this.users[i].posts.length; j++) {
                cacheAryPosts.push(this.users[i].posts[j]);
                counter++;
            }
        }
        this.sortAryByDate(cacheAryPosts);
        if (counter < num) {
            num = counter
            console.log("You requested more posts than exist sending all");
        }
        for (let i = 0; i < num; i++) {
            returnAryPosts[i] = cacheAryPosts[i];
        }
        return returnAryPosts;
    }

    sortAryByDate(ary) {
        var i, j, n = ary.length;
        for (i = 0; i < n - 1; i++) {
            for (j = 0; j < n - i - 1; j++) {
                if (ary[j].keyTime < ary[j + 1].keyTime) {
                    this.swap(ary, j, j + 1);
                }
            }
        }
    }

    swap(ary, xp, yp) {
        var temp = ary[xp];
        ary[xp] = ary[yp];
        ary[yp] = temp;
    }

    deletePost(username, title) {
        for (let i = 0; i < this.users.length; i++) {
            if (this.users[i].username == username) {
                for (let j = 0; j < this.users[i].posts.length; j++) {
                    if (this.users[i].posts[j].title == title) {
                        this.users[i].posts.splice(j, 1);
                        this.writeToFile();
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
module.exports.Database = Database;