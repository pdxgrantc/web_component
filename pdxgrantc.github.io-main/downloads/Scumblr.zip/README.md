Scumblr is a blog hosting web app. 
