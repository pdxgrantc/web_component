const lib = require("./database/lib.js");
const database = new lib.Database();

const express = require('express');
const bodyParser = require('body-parser');
const { text, json } = require('body-parser');
const textParser = bodyParser.text({ type: 'text/plain' })
const cookieParser = require("cookie-parser");
const sessions = require('express-session');
const { application } = require("express");
const app = express();

const port = 5555;

app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');

const oneDay = 1000 * 60 * 60 * 24;
var session;
app.use(sessions({
    secret: "thisismysecrctekeyfhrgfgrfrty84fwir767",
    saveUninitialized: true,
    cookie: { maxAge: oneDay, secure: false },
    resave: false
}));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

app.use(express.static(__dirname + '/static'));

const server = app.listen(port, function () {
    console.log('Node server is running on port ' + port + '. Link: http://localhost:' + port);
    console.log('Press Ctrl-C to quit.');
});

app.get('/', (req, res, next) => {
    session = req.session;
    if (session.userid) {
        console.log("Logged in as " + session.userid);
    }
    posts = database.latestPosts(5)
    res.render('index', {
        posts: JSON.stringify(posts),
        username: session.userid,
        login_status: session.userid ? true : false
    });
});

app.get('/login', (req, res, next) => {
    session = req.session;
    if (session.userid) {
        return res.redirect('/');
    }
    res.render('login_page', {
        redirect: "/",
        username: session.userid,
        login_status: session.userid ? true : false
    });
});

app.get('/signup', (req, res, next) => {
    session = req.session;
    if (session.userid) {
        console.log("Logged in as " + session.userid);
    }
    res.render('signup_page', {
        username: session.userid,
        login_status: session.userid ? true : false
    });
});

app.get('/create_post', (req, res, next) => {
    session = req.session;
    if (session.userid) {
        console.log("Logged in as " + session.userid);

        res.render('create_post_page', {
            username: session.userid,
            login_status: session.userid ? true : false
        });
    } else {
        res.render('login_page', {
            username: session.userid,
            redirect: '/create_post',
            login_status: session.userid ? true : false
        });
    }
});

app.get('/search/:searchterm', (req, res, next) => {
    session = req.session;
    if (session.userid) {
        console.log("Logged in as " + session.userid);
    }
    posts = database.searchPostsByTitle(req.params.searchterm)
    users = database.searchUsersByUsername(req.params.searchterm)
    res.render('search_results', {
        users: JSON.stringify(users),
        posts: JSON.stringify(posts),
        user: session.userid,
        login_status: session.userid ? true : false
    });
});

app.get('/:user', (req, res, next) => {
    session = req.session;
    let admin = false;
    if (session.userid) {
        console.log("Logged in as " + session.userid);
        if (session.userid === req.params.user) {
            admin = true;
        }
    }
    posts = database.getPosts(req.params.user);
    user = database.getUser(req.params.user);
    if (posts) {
        res.render('blog_page', {
            user: user.username,
            username: session.userid,
            userJoinTime: user.monthString + ' ' + user.year,
            posts: JSON.stringify(posts),
            admin: admin,
            login_status: session.userid ? true : false
        });
    } else {
        res.render('404.ejs', {
            username: session.userid,
            login_status: session.userid ? true : false
        })
    }
});

app.get('/:user/:post', (req, res, next) => {
    session = req.session;
    if (session.userid) {
        console.log("Logged in as " + session.userid);
    }
    var post = database.getPost(req.params.post);
    if (post) {
        res.render('blog_post_page', {
            user: req.params.user,
            username: session.userid,
            admin: session.userid === req.params.user,
            p: post,
            post: req.params.post,
            login_status: session.userid ? true : false
        });
    }
    else {
        res.render('404.ejs', {
            username: session.userid,
            login_status: session.userid ? true : false
        })
    }
});

app.post('/create_post', textParser, (req, res, next) => {
    session = req.session;
    if (session.userid) {
        console.log("Logged in as " + session.userid);
    }

    json_body = JSON.parse(req.body);

    console.log("Attempting to add new post to database:")
    console.log("   User:", json_body.user)
    console.log("   Title:", json_body.title)
    console.log("   Body:", json_body.body)
    console.log("   New user:", req.session.userid)

    var returnVal = database.newPost(req.session.userid, json_body.title, json_body.body);
    if (returnVal == 1) {
        console.log("--Post exists");
    }
    else if (returnVal == 2) {
        console.log("--Username given doesn't exist");
    }
    else {
        console.log("--Succeded");
    }

    res.send("/" + req.session.userid);
    res.statusCode = 200;
    res.end();
});

app.post('/delete_post', textParser, (req, res, next) => {
    session = req.session;

    console.log("Logged in as " + session.userid + " attempting to delete post: " + req.body + " with length " + req.body.length);

    db_response = database.deletePost(session.userid, req.body)
    if (db_response == true) {
        console.log("--Succeeded");
        res.send("success")
        res.statusCode = 200;
        res.end();
    } else {
        console.log("--Failed");
        res.send("failure");
        res.statusCode = 403;
        res.end();
    }
});

app.post('/new_login', textParser, (req, res, next) => {
    parsedJson = JSON.parse(req.body)

    user = database.getUser(parsedJson["username"])

    if (user) {
        if (user["password"] == parsedJson["password"]) {
            session = req.session;
            session.userid = user["username"];
            console.log("Session:", req.session);
            req.session.save();

            res.send("Thanks for logging in!");
            res.statusCode = 200;
            res.end();
        } else {
            console.log("Password did not match")
            res.send("Error: Invalid Password");
            res.statusCode = 403;
            res.end();
        }
    } else {
        console.log("Username did not match");
        res.send("Error: Invalid Username");
        res.statusCode = 404;
        res.end();
    }
});

app.post('/new_signup', textParser, (req, res, next) => {
    session = req.session;
    if (session.userid) {
        console.log("Logged in as " + session.userid);
    }
    console.log("Signup POST request received:");
    console.log("Body:", req.body);

    parsedJson = JSON.parse(req.body)
    database.newUser(parsedJson["username"], parsedJson["password"]);

    res.send("Thanks for signing up!");
    res.statusCode = 200;
    res.end()
});

app.post('/logout', textParser, (req, res, next) => {
    req.session.destroy();
    console.log("Logout POST request received.");

    res.redirect('/');
});

app.get('*', (req, res, next) => { /* 404 error */
    session = req.session;
    if (session.userid) {
        console.log("Logged in as " + session.userid);
    }
    res.render('404.ejs', {
        username: session.userid,
        login_status: session.userid ? true : false
    });
});
